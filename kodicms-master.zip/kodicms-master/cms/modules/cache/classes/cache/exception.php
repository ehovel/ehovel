<?php defined('SYSPATH') or die('No direct script access.');

class Cache_Exception extends Kohana_Cache_Exception {}