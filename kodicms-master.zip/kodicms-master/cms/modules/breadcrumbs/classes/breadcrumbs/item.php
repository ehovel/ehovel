<?php defined('SYSPATH') OR die('No direct script access!'); 

class Breadcrumbs_Item extends Kohana_Breadcrumbs_Item {}