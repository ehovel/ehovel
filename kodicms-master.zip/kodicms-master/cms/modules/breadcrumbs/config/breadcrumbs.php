<?php defined('SYSPATH') OR die('No direct script access!'); 

return array(
	'default' => array(
		'view' => 'line', //TODO: create a list view
		'urls' => TRUE, // change to false if you don't want urls on the breadcrumb items
		'active_class' => 'active'
	)
);