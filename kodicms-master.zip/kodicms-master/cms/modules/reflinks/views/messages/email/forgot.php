<h2>Здравствуйте, <?php echo $username; ?>!</h2>
<p>Ваш новый пароль <?php echo $password; ?></p>