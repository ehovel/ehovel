<?php if (!defined('SYSPATH')) die;

return array(
	'Add snippet' => 'Добавить сниппет',
	'Edit snippet' => 'Редактировать сниппет',

	'Snippet' => 'Сниппет',
	'Snippet <b>:name</b> has been added!' => 'Сниппет <b>:name</b> добавлен!',
	'Snippet <b>:name</b> has been deleted!' => 'Сниппет <b>:name</b> удален!',
	'Snippet <b>:name</b> has been saved!' => 'Сниппет <b>:name</b> сохранен!',
	'Snippet <b>:name</b> has not been added. Name must be unique!' => 'Сниппет <b>:name</b> не добавлен! Имя должно быть уникальным!',
	'Snippet <b>:name</b> has not been deleted!' => 'Сниппет <b>:name</b> не удален!',
	'Snippet <b>:name</b> has not been saved. Name must be unique!' => 'Сниппет <b>:name</b> не сохранен. Имя должно быть униальным!',
	'Snippet <b>:name</b> not found!' => 'Сниппет <b>:name</b> не найден!',
	'Snippet name' => 'Название сниппета',
	'Snippet not found!' => 'Сниппет не найден!',
	'Snippets' => 'Сниппеты',
);