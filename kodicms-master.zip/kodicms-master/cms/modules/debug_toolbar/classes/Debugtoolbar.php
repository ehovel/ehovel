<?php defined('SYSPATH') or die('No direct script access.');

/**
 * Kohana v3 Debug Toolbar
 *
 * @package Debug Toolbar
 * @author  Aaron Forsander <http://grimhappy.com/>
 * @author  Brotkin Ivan (BIakaVeron) <BIakaVeron@gmail.com>
 * @author  Sergei Gladkovskiy <smgladkovskiy@gmail.com>
 */
abstract class Debugtoolbar extends Kohana_Debugtoolbar {}