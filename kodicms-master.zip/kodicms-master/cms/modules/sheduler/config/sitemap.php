<?php defined('SYSPATH') or die('No direct access allowed.');

return array(
	'Content' => array(
		array(
			'name' => __('Sheduler'), 
			'url' => URL::backend('sheduler'),
			'priority' => 900
		)
	)
);
