<div class="outline">
	<div class="widget outline_inner">
		<div class="widget-content">
			<div id="calendar"></div>
		</div>
	</div>
</div>