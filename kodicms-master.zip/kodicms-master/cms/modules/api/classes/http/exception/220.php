<?php defined('SYSPATH') OR die('No direct script access.');

class HTTP_Exception_220 extends HTTP_API_Exception {

	/**
	 * @var   integer    HTTP 220
	 */
	protected $_code = 220;

}