<?php defined('SYSPATH') OR die('No direct script access.');

class HTTP_Exception_120 extends HTTP_API_Exception {

	/**
	 * @var   integer    HTTP 120
	 */
	protected $_code = 120;

}