<?php defined('SYSPATH') OR die('No direct script access.');

class HTTP_Exception_110 extends HTTP_API_Exception {

	/**
	 * @var   integer    HTTP 110
	 */
	protected $_code = 110;

}