<?php defined( 'SYSPATH' ) or die( 'No direct access allowed.' );

/**
 * http://twitter.github.com/bootstrap/base-css.html#images
 * @package    Twitte bootstrap/UI
 */
class UI_Image {
	
	const ROUNDED = 'img-rounded';
	const CIRCLE = 'img-circle';
	const POLAROID = 'img-polaroid';
	
}