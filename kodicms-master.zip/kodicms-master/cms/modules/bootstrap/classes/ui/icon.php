<?php defined( 'SYSPATH' ) or die( 'No direct access allowed.' );

/**
 * http://twitter.github.com/bootstrap/base-css.html#icons
 * @package    Twitte bootstrap/UI
 */
class UI_Icon {
	
	/*	
	 *		<i class="icon-search"></i>
	 *		<i class="icon-search icon-white"></i>
	 */
	const WHITE = 'icon-white';
}