<?php defined( 'SYSPATH' ) or die( 'No direct access allowed.' );

/**
 * http://twitter.github.com/bootstrap/components.html#labels-badges
 * @package    Twitte bootstrap/UI
 */
class UI_Label {
	
	const SUCCESS = 'label-success';
	const WARNING = 'label-warning';
	const IMPORTANT = 'label-important';
	const INFO = 'label-info';
	const INVERSE = 'label-inverse';
}