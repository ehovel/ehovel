<?php defined('SYSPATH') OR die('No direct script access.');

class Fragment extends Kohana_Fragment {
	
	/**
	 * Load a fragment from cache and display it. Multiple fragments can
	 * be nested with different life times.
	 *
	 *     if ( ! Fragment::load('footer')) {
	 *         // Anything that is echo'ed here will be saved
	 *         Fragment::save();
	 *     }
	 *
	 * @param   string  $name       fragment name
	 * @param   integer $lifetime   fragment cache lifetime
	 * @param   boolean $i18n       multilingual fragment support
	 * @return  boolean
	 */
	public static function load($name, $lifetime = NULL, $i18n = NULL)
	{
		// Set the cache lifetime
		$lifetime = ($lifetime === NULL) ? Fragment::$lifetime : (int) $lifetime;

		// Get the cache key name
		$cache_key = Fragment::_cache_key($name, $i18n);

		if ($fragment = Cache::instance()->get($cache_key))
		{
			// Display the cached fragment now
			echo $fragment;

			return TRUE;
		}
		else
		{
			// Start the output buffer
			ob_start();

			// Store the cache key by the buffer level
			Fragment::$_caches[ob_get_level()] = $cache_key;

			return FALSE;
		}
	}
	
	/**
	 * Saves the currently open fragment in the cache.
	 *
	 *     Fragment::save();
	 * 
	 * @param   array  $tags       cache tags
	 * @return  void
	 */
	public static function save_with_tags($lifetime = NULL, $tags = array())
	{
		// Get the buffer level
		$level = ob_get_level();

		if (isset(Fragment::$_caches[$level]))
		{
			// Get the cache key based on the level
			$cache_key = Fragment::$_caches[$level];

			// Delete the cache key, we don't need it anymore
			unset(Fragment::$_caches[$level]);

			// Get the output buffer and display it at the same time
			$fragment = ob_get_flush();
			
			// Set the cache lifetime
			$lifetime = ($lifetime === NULL) ? Fragment::$lifetime : (int) $lifetime;

			// Cache the fragment
			Cache::instance()
				->set_with_tags($cache_key, $fragment, $lifetime, $tags);
		}
	}
	
}
