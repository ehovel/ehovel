<?php defined('SYSPATH') or die('No direct access allowed.');

/**
 * @package    Kodi/Model
 */

class Model_Page_Role extends Record
{
    const TABLE_NAME = 'page_roles';

} // end Model_Page_Role class