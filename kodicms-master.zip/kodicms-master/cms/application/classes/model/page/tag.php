<?php defined('SYSPATH') or die('No direct access allowed.');

/**
 * @package    Kodi/Model
 */

class Model_Page_Tag extends Record
{
    const TABLE_NAME = 'page_tags';
} // end class Model_Page_Tag