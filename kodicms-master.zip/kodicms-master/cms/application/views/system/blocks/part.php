<!-- Start block page::<?php echo $page->id; ?>::part::<?php echo $part; ?> -->
<?php echo $html; ?>
<!-- End block page::<?php echo $page->id; ?>::part::<?php echo $part; ?> -->