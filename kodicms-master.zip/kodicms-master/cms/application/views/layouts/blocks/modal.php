<div class="modal hide" id="modal-window">
    <div class="modal-header">
		<h3></h3>
    </div>
    <div class="modal-body"></div>
    <div class="modal-footer"></div>
</div>