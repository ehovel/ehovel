<?php defined( 'SYSPATH' ) OR die( 'No direct script access.' );

return array(
	'default' => array(
		// TODO сделать генерацию через инсталлятор
		'key' => 'trwQwVXX96TIJoKxyBHB9AJkwAOHixuV1ENZmIWyanI0j1zNgSVvqywy044Agaj',
		'cipher' => MCRYPT_RIJNDAEL_128,
		'mode' => MCRYPT_MODE_NOFB,
	),
);
