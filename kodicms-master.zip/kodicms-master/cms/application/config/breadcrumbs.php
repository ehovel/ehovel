<?php defined('SYSPATH') OR die('No direct script access!'); 

return array(
	'default' => array(
		'view' => 'layouts/blocks/breadcrumbs',
		'urls' => TRUE,
		'active_class' => 'active'
	)
);