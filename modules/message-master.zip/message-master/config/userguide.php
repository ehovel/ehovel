<?php defined('SYSPATH') or die('No direct script access.');

return array
(
	'modules' => array
	(
		'message' => array
		(
			'enabled' => TRUE,
			'name' => "Message",
			'description' => "A flash messaging system for Kohana v3.0 and higher.",
			'copyright' => '&copy; 2010–2011 Dave Widmer',
		)  
	)
);
