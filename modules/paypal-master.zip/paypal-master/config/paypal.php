<?php defined('SYSPATH') or die('No direct script access.');

return array(

	// PayPal API and username
	'username' => NULL,
	'password' => NULL,

	// PayPal API signature
	'signature' => NULL,

	// PayPal environment: live, sandbox, beta-sandbox
	'environment' => 'sandbox',

);
