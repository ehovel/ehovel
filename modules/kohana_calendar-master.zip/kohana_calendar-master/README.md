# Kohana v2 Calendar port to Kohana v3

### [Documentation](http://docs.kohanaphp.com/libraries/calendar)

#### new added
- `render()` has now a paramerter that defines the location of the `View` file