<?php defined('SYSPATH') or die('No direct access allowed.');

class Notices extends Kohana_Notices {}
