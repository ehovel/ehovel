<?php defined('SYSPATH') or die('No direct access allowed.');

return array
(

	// Path to the images
	'image_path' => 'media/images/',

);
