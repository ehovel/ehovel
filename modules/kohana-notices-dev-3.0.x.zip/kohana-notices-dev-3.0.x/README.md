# Notices

*Notices module for Kohana 3.x*

- **Module Version:** 3.0.x
- **Module URL:** <http://github.com/synapsestudios/kohana-notices>
- **Compatible Kohana Version(s):** 3.1.x

## Description

The purpose of this module is to provide an easy way to send messages to the
user on any page, based on events and decisions in the application. Most
commonly, these message are used to inform users of errors. The Notices module
uses the session to pass messages on to the next page.
