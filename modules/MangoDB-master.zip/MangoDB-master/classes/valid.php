<?php defined('SYSPATH') OR die('No direct access allowed.');

class Valid extends Mango_Valid {}