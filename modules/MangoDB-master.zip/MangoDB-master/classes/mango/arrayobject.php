<?php

class Mango_ArrayObject extends Kohana_Mango_ArrayObject {}