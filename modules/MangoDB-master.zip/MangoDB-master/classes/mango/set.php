<?php

class Mango_Set extends Kohana_Mango_Set {}