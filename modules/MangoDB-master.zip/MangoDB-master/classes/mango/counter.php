<?php

class Mango_Counter extends Kohana_Mango_Counter {}