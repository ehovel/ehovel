<?php

return array(
	// Inheritance data
	/*'car' =>  array(
		'car_type' => array(
			1 => 'Spyker',
			2 => 'Ferrari'
		)
	),
	// you could specify even further extension
	// (extension of extension) using the same pattern
	// 'spyker' => array( etc
	*/
);