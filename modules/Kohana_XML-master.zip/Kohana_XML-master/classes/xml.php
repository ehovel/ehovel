<?php defined('SYSPATH') or die('No direct script access.');
/**
 *	Document   : xml.php
 *	Created on : 1 mai 2009, 13:03:03
 *	@author Cedric de Saint Leger <c.desaintleger@gmail.com>
 *
 *	Description:
 *      XML class. Use this class to override XML_Core.
 *      Extend this class to make your own XML based driver (Atom, XRDS, GData, RSS, PodCast RSS, or your own brewed XML format)
 */

 class XML extends XML_Core
 {}