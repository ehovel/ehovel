<?php defined('SYSPATH') or die('No direct script access.');
/**
 *	Document   : meta.php
 *	Created on : 1 mai 2009, 13:03:03
 *	@author Cedric de Saint Leger <c.desaintleger@gmail.com>
 *
 *	Description:
 *      XML_Meta class. Use this to override XML_Meta_Core
 */

class XML_Meta extends XML_Meta_Core {}
