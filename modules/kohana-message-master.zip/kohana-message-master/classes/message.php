<?php defined('SYSPATH') or die('No direct script access.');

class Message extends Kohana_Message { }