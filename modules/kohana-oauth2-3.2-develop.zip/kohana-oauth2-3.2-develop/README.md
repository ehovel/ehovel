# Kohana OAuth2 Module Readme

This is very much a work in progress.. Comments welcome :)

(Crappy and outdated) Docs are provided as part of the module, to view them, ensure you have the userguide module installed.

Example consumer: https://github.com/managedit/kohana-oauth2-example-consumer
Example provider: https://github.com/managedit/kohana-oauth2-example-provider
