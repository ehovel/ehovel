<?php defined('SYSPATH') or die('No direct script access.');

class Controller_OAuth2_Endpoints extends Kohana_Controller_OAuth2_Endpoints {}