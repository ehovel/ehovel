<?php defined('SYSPATH') or die('No direct script access.');

class Model_OAuth2_Client extends Kohana_Model_OAuth2_Client {}