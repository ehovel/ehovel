<?php defined('SYSPATH') or die('No direct script access.');

class Model_OAuth2_Refresh_Token extends Kohana_Model_OAuth2_Refresh_Token {}