<?php defined('SYSPATH') or die('No direct script access.');

class Model_OAuth2_Access_Token extends Kohana_Model_OAuth2_Access_Token {}