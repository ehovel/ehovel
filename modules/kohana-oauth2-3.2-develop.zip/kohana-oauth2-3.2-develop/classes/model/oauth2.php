<?php defined('SYSPATH') or die('No direct script access.');

abstract class Model_OAuth2 extends Kohana_Model_OAuth2 {}