<?php defined('SYSPATH') or die('No direct script access.');

abstract class OAuth2_Consumer_GrantType extends Kohana_OAuth2_Consumer_GrantType {}