<?php defined('SYSPATH') or die('No direct script access.');

class OAuth2_Consumer_GrantType_Authorization_Code extends Kohana_OAuth2_Consumer_GrantType_Authorization_Code {}