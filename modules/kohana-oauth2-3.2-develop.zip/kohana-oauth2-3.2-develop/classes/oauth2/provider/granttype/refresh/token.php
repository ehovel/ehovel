<?php defined('SYSPATH') or die('No direct script access.');

class OAuth2_Provider_GrantType_Refresh_Token extends Kohana_OAuth2_Provider_GrantType_Refresh_Token {}