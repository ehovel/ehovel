<?php defined('SYSPATH') or die('No direct script access.');

class OAuth2_Provider_GrantType_Password extends Kohana_OAuth2_Provider_GrantType_Password {}