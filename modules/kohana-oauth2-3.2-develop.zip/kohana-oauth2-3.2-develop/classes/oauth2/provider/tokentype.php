<?php defined('SYSPATH') or die('No direct script access.');

abstract class OAuth2_Provider_TokenType extends Kohana_OAuth2_Provider_TokenType {}