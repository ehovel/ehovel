<?php defined('SYSPATH') or die('No direct script access.');

class OAuth2_Provider_TokenType_Mac extends Kohana_OAuth2_Provider_TokenType_Mac {}