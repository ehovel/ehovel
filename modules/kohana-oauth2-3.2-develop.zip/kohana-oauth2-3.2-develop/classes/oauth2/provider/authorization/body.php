<?php defined('SYSPATH') or die('No direct script access.');

class OAuth2_Provider_Authorization_Body extends Kohana_OAuth2_Provider_Authorization_Body {}