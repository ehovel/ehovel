<?php defined('SYSPATH') or die('No direct script access.');

abstract class OAuth2_Provider_Authorization extends Kohana_OAuth2_Provider_Authorization {}