<?php defined('SYSPATH') or die('No direct script access.');

class OAuth2_Exception_InsufficientScope extends Kohana_OAuth2_Exception_InsufficientScope {}