<?php defined('SYSPATH') or die('No direct script access.');

class OAuth2_Exception_InvalidRequest extends Kohana_OAuth2_Exception_InvalidRequest {}