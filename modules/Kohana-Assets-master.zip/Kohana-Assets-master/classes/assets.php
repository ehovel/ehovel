<?php defined('SYSPATH') or die('No direct script access.');

class Assets extends Assets_Core {}