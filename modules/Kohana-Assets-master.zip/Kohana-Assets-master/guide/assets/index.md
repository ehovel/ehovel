# Asset Manager

## About

Allows assets (CSS, Javascript, etc.) to be included throughout the application, and then outputted later based on dependencies.
This makes sure all assets will be included in the correct order, no matter what order they are defined in.