#Development roadmap

## Server mode ##

1. Extensions
   code, token, authorization_code, implicit, client credentials

2. Authentications
   bear, mac

### Model process ###

### Client profiles support ###


## Client mode ##


## Demo app ##


## User guide book ##
