<?php defined('SYSPATH') or die('No direct script access.'); ?>
Do you want to import you personal information from example.com ? <br />
Yeah, of cause ! <a href="<?php echo url::site('client/code'); ?>">Let's go</a>
