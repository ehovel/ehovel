## Client component ##

### Install and configuration ###

### Communicate with OAuth 2 server ###
