## Server ##

### Install and configuration ###

### Resources management interface ###