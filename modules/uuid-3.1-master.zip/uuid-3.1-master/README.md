# Universally Unique Identifiers

RFC 4122 compliant UUID (or GUID) helper class for the Kohana PHP Framework. For more information, read [the guide](http://github.com/shadowhand/uuid/wiki).
