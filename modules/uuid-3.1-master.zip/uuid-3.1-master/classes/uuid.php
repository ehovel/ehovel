<?php defined('SYSPATH') or die('No direct script access.');

class UUID extends Kohana_UUID {  }
