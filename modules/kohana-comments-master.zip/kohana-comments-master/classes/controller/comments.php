<?php defined('SYSPATH') OR die('No direct script access.');

class Controller_Comments extends Controller_Comments_Core { }
