<?php defined('SYSPATH') or die('No direct script access.');

// Autoloading for Swiftmailer
require Kohana::find_file('vendor/swiftmailer', 'lib/swift_required');
