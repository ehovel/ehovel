<?php defined('SYSPATH') or die('No direct script access.');
/**
 * Contains the Google Map class.
 *
 * @package    gmap
 * @author     Leonard Fischer <leonard.fischer@sn4ke.de>
 * @copyright  (c) 2011 Leonard Fischer
 * @version    1.3
 */
class Gmap extends Gmap_Core {}