<?php defined('SYSPATH') OR die('No direct access allowed.');
/**
 * Modified Preorder Tree Traversal Class.
 *
 * @author     Kiall Mac Innes
 * @author     Mathew Davies
 * @author     Mike Parkin
 * @copyright  (c) 2008-2010
 * @package    ORM_MPTT
 */
class Model_Test_ORM_MPTT extends ORM_MPTT {
	protected $_table_name = 'test_orm_mptt';
}
