<?php defined('SYSPATH') or die('No direct script access.');

return array(
	'index_path' => 'searchindex',
	'use_english_stemming_analyser' => TRUE,
);